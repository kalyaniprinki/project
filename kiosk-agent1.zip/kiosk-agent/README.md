
# Kiosk Agent (Advanced)

## Features
- Printer detection
- PDF printing
- Download file from backend & print
- Zero native compilation

## Install
npm install

## Run
node index.js

Service runs at:
http://localhost:9100
