const express = require("express");
const cors = require("cors");
const { print, getPrinters } = require("pdf-to-printer");
const fs = require("fs");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json());

// =========================
// Status Endpoint (LOCAL)
// =========================
app.get("/status", async (req, res) => {
  let printers = [];

  try {
    printers = await getPrinters();

    // Filter unsupported printers
    printers = printers.filter(
      p =>
        p.PortName &&
        !p.PortName.toLowerCase().includes("nul") &&
        !p.PortName.toLowerCase().includes("pdfarchitect")
    );

    // Fallback to Microsoft Print to PDF if no usable printers
    if (printers.length === 0) {
      printers = [{ name: "PDFCreator" }];
    }
  } catch (err) {
    // console.warn("⚠ Could not fetch printers:", err.message);
    printers = [{ name: "PDFCreator" }];
  }

  // console.log("📄 Connected Printers:", printers.map(p => p.name));

  res.json({
    printerConnected: printers.length > 0,
    printers,
  });
});

// =========================
// Print Endpoint
// =========================

app.post("/print", async (req, res) => {
  try {
    const { filePath } = req.body;
    const url=filePath;
    // if (!url) {
    //   return res.status(400).json({ error: "PDF URL is required" });
    // }

    console.log("📥 /print (cloud) called with URL:", url);

    const https = require("https");
    const os = require("os");

    // Create temp folder
    const tempDir = path.join(os.tmpdir(), "kiosk-pdf");
    fs.mkdirSync(tempDir, { recursive: true });

    const localFile = path.join(tempDir, `${Date.now()}.pdf`);

    console.log("⬇ Downloading PDF to:", localFile);

    // Download file from URL
    await new Promise((resolve, reject) => {
      const file = fs.createWriteStream(localFile);

      https.get(url, response => {
        response.pipe(file);
        file.on("finish", () => file.close(resolve));
      }).on("error", reject);
    });

    console.log("📄 PDF downloaded. Sending to printer...");

    // Always use PDFCreator (works on all Windows machines)
    await print(localFile, { printer: "PDFCreator" });

    res.json({
      success: true,
      message: "Print started"
    });

  } catch (err) {
    console.error("❌ Print error:", err.message);
    res.status(500).json({ error: err.message });
  }
});


// app.post("/print", async (req, res) => {
//   const { filePath } = req.body;
//   console.log("/print called with body:", req.body);

//   // if (!filePath || !fs.existsSync(filePath)) {
//   //   return res.status(400).json({ error: "File not found on kiosk" });
//   // }

//   try {
//     const printers = await getPrinters();
//     let printerName = "PDFCreator"; // default

//     // Use the first valid printer if available
//     // if (printers && printers.length > 0) {
//     //   const valid = printers.find(
//     //     p => p.PortName && !p.PortName.toLowerCase().includes("nul")
//     //   );
//     //   if (valid) printerName = valid.name;
//     // }

//     console.log("📄 Printing on:", printerName);

//     await print(filePath, { printer: printerName });
//     res.json({ message: "Print started" });
//   } catch (err) {
//     console.error("❌ Print error:", err.message);
//     res.status(500).json({ error: err.message });
//   }
// });

// =========================
// Download & Print Endpoint
// =========================
app.post("/download-and-print", async (req, res) => {
  const { url } = req.body;
  if (!url) return res.status(400).json({ error: "Missing URL" });

  const localPath = path.join(__dirname, "downloads", Date.now() + ".pdf");
  fs.mkdirSync(path.dirname(localPath), { recursive: true });

  const https = require("https");
  const file = fs.createWriteStream(localPath);

  https.get(url, response => {
    response.pipe(file);
    file.on("finish", async () => {
      file.close();

      try {
        const printers = await getPrinters();
        let printerName = "PDFCreator";

        if (printers && printers.length > 0) {
          const valid = printers.find(
            p => p.PortName && !p.PortName.toLowerCase().includes("nul")
          );
          if (valid) printerName = valid.name;
        }

        console.log("📄 Downloaded file will print on:", printerName);

        await print(localPath, { printer: printerName });
        res.json({ message: "Downloaded & printed" });
      } catch (err) {
        console.error("❌ Download & print error:", err.message);
        res.status(500).json({ error: err.message });
      }
    });
  }).on("error", (err) => {
    console.error("❌ Download error:", err.message);
    res.status(500).json({ error: err.message });
  });
});

// =========================
// Start Kiosk Agent Server
// =========================
app.listen(9100, () => console.log("Kiosk Agent running on port 9100"));
